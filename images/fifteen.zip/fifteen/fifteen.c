/**
 * fifteen.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Implements Game of Fifteen (generalized to d x d).
 *
 * Usage: fifteen d
 *
 * whereby the board's dimensions are to be d x d,
 * where d must be in [DIM_MIN,DIM_MAX]
 *
 * Note that usleep is obsolete, but it offers more granularity than
 * sleep and is simpler to use than nanosleep; `man usleep` for more.
 */

#define _XOPEN_SOURCE 500

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

// constants
#define DIM_MIN 3
#define DIM_MAX 9

// board
int board[DIM_MAX][DIM_MAX];

// dimensions
int d;

// prototypes
void clear(void);
void greet(void);
void init(void);
void draw(void);
bool move(int tile);
bool won(void);


void sort(int values[], int n);

int main(int argc, string argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        printf("Usage: fifteen d\n");
        return 1;
    }

    // ensure valid dimensions
    d = atoi(argv[1]);
    if (d < DIM_MIN || d > DIM_MAX)
    {
        printf("Board must be between %i x %i and %i x %i, inclusive.\n",
            DIM_MIN, DIM_MIN, DIM_MAX, DIM_MAX);
        return 2;
    }

    // open log
    FILE* file = fopen("log.txt", "w");
    if (file == NULL)
    {
        return 3;
    }

    // greet user with instructions
    greet();

    // initialize the board
    init();

    // accept moves until game is won
    while (true)
    {
        // clear the screen
        clear();

        // draw the current state of the board
        draw();

        // log the current state of the board (for testing)
        for (int i = 0; i < d; i++)
        {
            for (int j = 0; j < d; j++)
            {
                fprintf(file, "%i", board[i][j]);
                if (j < d - 1)
                {
                    fprintf(file, "|");
                }
            }
            fprintf(file, "\n");
        }
        fflush(file);

        // check for win
        if (won())
        {
            printf("\033[1;31m");
            printf("You Won!\n");
            break;
        }

        // prompt for move
        printf("Tile to move: ");
        int tile = get_int();

        // quit if user inputs 0 (for testing)
        if (tile == 0)
        {
            break;
        }

        // log move (for testing)
        fprintf(file, "%i\n", tile);
        fflush(file);

        // move if possible, else report illegality
        if (!move(tile))
        {
            printf("\nIllegal move.\n");
            usleep(500000);
        }

        // sleep thread for animation's sake
        usleep(0);
    }

    // close log
    fclose(file);

    // success
    return 0;
}

/**
 * Clears screen using ANSI escape sequences.
 */
void clear(void)
{
    printf("\033[2J");
    printf("\033[%d;%dH", 0, 0);
}

/**
 * Greets player.
 */
void greet(void)
{
    clear();
    printf("WELCOME TO GAME OF FIFTEEN\n");
    usleep(2000000);
}

/**
 * Initializes the game's board with tiles numbered 1 through d*d - 1
 * (i.e., fills 2D array with values but does not actually print them).
 */
void init(void)
{
    // holds number to insert
    int holder = (d * d - 1);

    int row = 0;
    int column = 0;


    if (d % 2 == 0)// NOTE: d is dimensions in top of file
    {
        // defalut number in an Even boarad
        board[d - 1][d - 1] = 0; // check50 uses 0 for space
        board[d - 1][d - 2] = 2;
        board[d - 1][d - 3] = 1;

        // put numbers in board
        for (int i = 0; i < ((d * d) - 3); i++) // d * d or square(d) id the number of numbers in the game including 0
        {
            if (column > (d - 1))
            {
                column = 0;
                row++;
            }
            board[row][column] = holder;
            holder--;
            column++;
        }
    }
    else
    {
        // put numbers in board
        for (int i = 0; i < ((d * d)); i++)
        {
            if (column  > (d - 1))
            {
                column = 0;
                row++;
            }
            board[row][column] = holder;
            holder--;
            column++;
        }
    }

}


/**
 * Prints the board in its current state.
 */
void draw(void)
{
    // TODO
    // just another way to loop through board
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            // prevent print() 0
            if (board[i][j] == 0)
            {
                printf("_  ");
            }
            else
            {
                printf("%i   ", board[i][j]);
            }
        }
        printf("\n\n");
    }
}

/**
 * If tile borders empty space, moves tile and returns true, else
 * returns false.
 */
bool move(int tile)
{
    // TODO
    int counter = 0;
    int row_position_zero;
    int column_position_zero;
    //search for tile
    //NOTE: i don't have to check if tile is 0 it's already checked for upove
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            if (board[i][j] == tile)
            {
                // search for 0 (space) and get index for swich
                for (int x = 0; x < d; x++)
                {
                    for (int y = 0; y < d; y++)
                    {
                        if (board[x][y] == 0)
                        {
                            row_position_zero = x;
                            column_position_zero = y;
                        }
                    }
                }

                board[i][j] = 0;// [i][j] is the position of the tile picked which is the current position in the loop
                board[row_position_zero][column_position_zero] = tile; // i could've also used [x][y] for this butt this is more clear
                return true;
                break;
            }


            counter++;

        }
    }
    return false;
}


/**
 * Returns true if game is won (i.e., board is in winning configuration),
 * else false.
 */
 // i don't know if this function is complete i don't have a way to test it i tried ./fifteen 3 < ~cs50/pset3/3x3.txt butt it doesn't work
bool won(void)
{
    //make new array
    int compare_Array[d][d];

    //copy old array to new
    for (int i = 0; i < d; i++)
    {
        for (int j = 0; j < d; j++)
        {
            compare_Array[i][j] = board[i][j];
        }
    }

    //sort new array
    sort(*compare_Array, (d * d));// NOTE: if the number of rows matches the number of columns then the number of elemnts in that Array or matrix is (ROWS * COLUMNS)

    int row = 0;
    int column = 0;
    int wrong_counter = 0;
    //compare arrays
    for (int i = 0; i < (d * d); i++)
    {
        if (column > (d - 1))
        {
            column = 0;
            row++;
        }

        if (i == 0)
        {
            printf("%i = %i\n", board[row][column], compare_Array[row][column + 1]);
            printf("column = %i\n", column);
            if (board[row][column] != compare_Array[row][column + 1])// this is because sorting mad 0 at first
            {
                wrong_counter++;
            }
        }
        else if (i == ((d * d) - 1))
        {
            printf("%i = %i\n", board[row][column], 0);
            printf("column = %i\n", column);
            if (board[row][column] != 0)// this is because sorting mad 0 at first
            {
                wrong_counter++;
            }
        }
        else
        {
            printf("%i = %i\n", board[row][column], compare_Array[row][column + 1]);
            printf("column = %i\n", column + 1);
            if (board[row][column] != compare_Array[row][column + 1]) // so this does make an error but the numbers that can be accessed get accessed anyway
            {
                wrong_counter++;
            }
        }
        column++;
    }

    if (wrong_counter == 0)
    {
        return true;
    }
    else
    {
        return false;
    }

}












void sort(int values[], int n)
{
    if (n < 2)
    {
        return;
    }
    else
    {
        // smallest number found during loop
        int smallest = values[0];
        // the first index that's not sorted
        int switch_with_index = 0;
        // index of smallest number found during loop
        int index_smallest;
        // variable for switching values
        int switch_value_holder;
        // bool for unsorted elemnt
        int counter = 0;

        while (true)
        {
            // if no numbers to sort / if reached last number in the sorting
            if (counter == (n - 1))//////////////////////////////////// the problem is here
            {
                return;
            }

            // find smallest
            for (int i = switch_with_index; i < n; i++)
            {
                if (values[i] < smallest)
                {
                    smallest = values[i];
                    index_smallest = i;
                }

            }
            if (smallest == values[switch_with_index])
            {
                index_smallest = switch_with_index;
            }

            // switch numbers
            switch_value_holder = values[index_smallest];
            values[index_smallest] = values[switch_with_index];
            values[switch_with_index] = switch_value_holder;


            // reasign values for next loop
            ++switch_with_index;
            smallest = values[switch_with_index];


            counter++;
        }
    }
}